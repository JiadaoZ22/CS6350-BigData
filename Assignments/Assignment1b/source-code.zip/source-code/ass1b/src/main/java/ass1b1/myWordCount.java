package ass1b1;


import example.MiscUtils;
import org.apache.commons.httpclient.URIException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.fs.LocatedFileStatus;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.fs.RemoteIterator;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;
import org.apache.log4j.Logger;

import java.io.*;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.Pattern;


public class myWordCount extends Configured implements Tool {

  private static final Logger LOG = Logger.getLogger(myWordCount.class);
  private static String StopWordListPath = System.getProperty("user.dir")+"/";

  public static void main(String[] args) throws Exception {
    int res = ToolRunner.run(new myWordCount(), args);
    System.exit(res);
  }

//  private static Set<String> geStoptWords() throws FileNotFoundException,IOException {
//    Configuration config = context.get
//
//    nioPath path = java.nio.file.Path.get
////    File file = new File(url.toURI());
////    Path path = new Path(url);  // hdfs
//    String stopwordString = new String(Files.readAllBytes(path));
////    return stopwordString.split(",");
////    Set<String> stopwordSet =  new HashSet<String>(Arrays.asList(stopwordString.split(",")));
//    return new HashSet<String>(Arrays.asList(stopwordString.split(",")));
//  }


  public int run(String[] args) throws Exception {
//    System.out.println("get into run");
    Job job = Job.getInstance(getConf(), "mywordcount");
    job.setJarByClass(this.getClass());
    StopWordListPath += "stopwords.txt";
    System.out.println("Stopwords file path: " + StopWordListPath);
//    System.out.println("Stopwords file path: " + myWordCount.class.getResource(StopWordListPath).toString());
//    job.getConfiguration().set("path.stopwords.file", StopWordListPath);
    job.getConfiguration().set("path.stopwords.file", args[2]);


    // Use TextInputFormat, the default unless job.setInputFormatClass is used
    // arg[0] is the input folder name
    try{
      Configuration config = new Configuration();
      FileSystem fs = FileSystem.get(config);
//      System.out.println(fs.listStatus(new Path("")).length);
      RemoteIterator<LocatedFileStatus> iterator = fs.listFiles(new Path(args[0]), true);
      while(iterator.hasNext()){
        LocatedFileStatus lfs = iterator.next();
//        System.out.println(lfs.getPath());
        FileInputFormat.addInputPath(job, lfs.getPath());

//        BufferedReader br = new BufferedReader(new InputStreamReader(fs.open(lfs.getPath())));
//        InputStreamReader ir = new InputStreamReader(fs.open(lfs.getPath()));
//        List<String> lines = Files.readAllLines(Paths.get(), StandardCharsets.UTF_8);
//        for(String line:lines){
//          if(!line.isEmpty()){
//            FileInputFormat.addInputPath(job, new Path(line));
//          }
//        }
      }
      fs.delete(new Path(args[1]), true);
    } catch (Exception e){
      e.printStackTrace();
    }
    FileOutputFormat.setOutputPath(job, new Path(args[1]));

//    job.getConfiguration().setBoolean("wordcount.case.sensitive",false);
    // get stopwrods-list
//    if(args.length > 2 && "-skip".equals(args[2])){
//      job.getConfiguration().set("path.stopwords.file", args[3]);
//    }

    job.setMapperClass(Map.class);
    job.setCombinerClass(Reduce.class);
    job.setReducerClass(Reduce.class);
    job.setOutputKeyClass(Text.class);
    job.setOutputValueClass(IntWritable.class);
    return job.waitForCompletion(true) ? 0 : 1;
  }


  public static class Map extends Mapper<LongWritable, Text, Text, IntWritable> {
    private final static IntWritable one = new IntWritable(1);
    private Text word = new Text();
    private boolean caseSensitive = false;
    private static final Pattern WORD_BOUNDARY = Pattern.compile("\\s*\\b\\s*");
    private Set<String> stopwordSet;

    protected void setup(Context context)
      throws IOException, InterruptedException {
      Configuration config = context.getConfiguration();
      this.caseSensitive = config.getBoolean("wordcount.case.sensitive", false);

      //  get stopwordSet
//      System.out.println("----------------------------------");
//      System.out.println("Get StopWordListPath:"+StopWordListPath);
//      System.out.println(myWordCount.class.getResource("/"));
//      URL url = myWordCount.class.getResource(StopWordListPath);
      String file;
      if ((file = config.get("path.stopwords.file")) != null) {
        Path path = new Path(file);
        FileSystem fs = FileSystem.get(config);
        BufferedReader br = new BufferedReader(new InputStreamReader(fs.open(path)));
        String line;
        stopwordSet = new HashSet<String>();
        while ((line = br.readLine()) != null) {
          String[] stopwords = line.split(",");
          Collections.addAll(stopwordSet, stopwords);
//          for(String sw:stopwords){
//            if (sw != null)   stopwordSet.add(sw);
//          }
        }
      }
    }

    public void map(LongWritable offset, Text lineText, Context context)
        throws IOException, InterruptedException {
      String line = lineText.toString();
      if (!caseSensitive) {
        line = line.toLowerCase();
      }
      Text currentWord = new Text();
        for (String word : WORD_BOUNDARY.split(line)) {
          if (word.isEmpty()) {
            continue;
          }

          // remove non-word chars \W:',' or '.'
          word = word.replaceAll("\\W","");

          // remove length under 5
          if (stopwordSet.contains(word) || word.length() < 5) continue;

          currentWord = new Text(word);
          context.write(currentWord,one);
        }         
      }
  }




  public static class Reduce extends Reducer<Text, IntWritable, Text, IntWritable> {
    @Override
    public void reduce(Text word, Iterable<IntWritable> counts, Context context)
        throws IOException, InterruptedException {
      int sum = 0;
      for (IntWritable count : counts) {
        sum += count.get();
      }
      context.write(word, new IntWritable(sum));
    }
  }
}
